/**
 * Componente: CP08 Comparativo Granja Galpón
 * Módulo: Costo Diario
 * 
 * 3 Paneles interactivos con Filtro Cruzado y Tooltips idénticos a Tableau:
 * 1. Datos Productivos (histodatosprodcompa) -> Clic en Galpón filtra Paneles 2 y 3 a ese galpón.
 * 2. Comparación Línea (histodatosalmalineacompa) -> Clic en Línea filtra Panel 3 a esa línea.
 * 3. Comparativo Detalle Productos (histodatosalmacompa) -> Matriz pivotada interactiva.
 */

window.ChartCP08ComparativoGranjaGalpon = {
    datosBackend: null,
    catalogoGranjas: null,
    cencosActivo: null,
    nomcencosActivo: null,
    galponActivo: null,
    lineaSeleccionada: null,
    galponesSeleccionados: [],
    lineasSeleccionadas: [],
    datosPorCencos: {},
    promesasCencos: {},
    cargaSeq: 0,
    multiGranja: null,
    multiClasif: null,

    render(controller, data) {
        if (!data && controller && controller.tabla1_datos_productivos) {
            data = controller;
        }
        this.datosBackend = data || {};
        if (data && data.filtros_disponibles && data.filtros_disponibles.granjas_catalogo) {
            this.catalogoGranjas = data.filtros_disponibles.granjas_catalogo;
        }
        this.cencosActivo = data.cencos_activo || (data.tabla1_datos_productivos?.granjas?.[0]?.cencos) || null;
        this.nomcencosActivo = data.nomcencos_activo || (data.tabla1_datos_productivos?.granjas?.[0]?.nomcencos) || '';
        this.galponActivo = null;
        this.lineaSeleccionada = null;
        this.galponesSeleccionados = [];
        this.lineasSeleccionadas = [];
        this.datosPorCencos = {};
        this.promesasCencos = {};
        this.cargaSeq = (this.cargaSeq || 0) + 1;
        this.generacionDatos = (this.generacionDatos || 0) + 1;

        if (this.cencosActivo) {
            this.datosPorCencos[String(this.cencosActivo)] = {
                tabla2: data.tabla2_comparacion_linea || {},
                tabla3: data.tabla3_comparativo_detalle || {},
                nomcencos: this.nomcencosActivo
            };
        }

        // 1. Ocultar contenedores estándar
        const headerPrincipal = document.getElementById('card-header-grafica-principal');
        if (headerPrincipal) headerPrincipal.classList.add('hidden');

        const cardTabla = document.getElementById('card-tabla-metricas');
        if (cardTabla) cardTabla.classList.add('hidden');

        // Mostrar botón de exportación a PDF exclusivo de CP08
        const btnPdf = document.getElementById('btn-exportar-pdf-cp08');
        if (btnPdf) btnPdf.classList.remove('hidden');

        // 2. Configurar Filtros Superiores
        this.setupFilters(data);

        // 3. Renderizar Layout Visual
        this.renderLayout();
    },

    destroy() {
        const btnPdf = document.getElementById('btn-exportar-pdf-cp08');
        if (btnPdf) btnPdf.classList.add('hidden');
    },

    async exportarPdf(controller) {
        if (!this.datosBackend || !this.datosBackend.tabla1_datos_productivos) {
            alert('Primero debe cargar los datos del gráfico.');
            return;
        }

        const btn = document.getElementById('btn-exportar-pdf-cp08');
        const originalHtml = btn ? btn.innerHTML : '';
        if (btn) {
            btn.disabled = true;
            btn.classList.add('opacity-75', 'cursor-not-allowed');
            btn.innerHTML = `
                <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Generando PDF...</span>
            `;
        }

        const ventanaPdf = window.open('', '_blank');

        try {
            // Asegurar que estén cargados todos los cencos seleccionados antes de generar el PDF.
            await this.asegurarDatosCencos();

            let rango = {};
            if (typeof PeriodoHelper !== 'undefined' && PeriodoHelper.obtenerRangoFechas) {
                rango = PeriodoHelper.obtenerRangoFechas();
            }

            const gruposPdf = this.obtenerGruposPaneles();

            const payload = {
                datos: this.datosBackend,
                seleccion: {
                    cencosActivo: this.cencosActivo,
                    nomcencosActivo: this.nomcencosActivo,
                    galponActivo: this.galponActivo,
                    lineaSeleccionada: this.lineaSeleccionada,
                    selectedGranjas: this.multiGranja ? this.multiGranja.getSelectedValues() : [],
                    selectedClasif: this.multiClasif ? this.multiClasif.getSelectedValues() : [],
                    galponesSeleccionados: this.galponesSeleccionados,
                    lineasSeleccionadas: this.lineasSeleccionadas,
                    grupos: gruposPdf
                },
                filtros: {
                    fecha_inicio: rango.fechaInicio || rango.inicio || '',
                    fecha_fin: rango.fechaFin || rango.fin || '',
                    fecha_formateada: this.datosBackend.fecha_formateada || `${rango.fechaInicio || ''} al ${rango.fechaFin || ''}`
                }
            };

            const service = (controller && controller.service) || window.costoDiarioController?.service || new CostoDiarioService();
            const blob = await service.exportarPdfCP08(payload);

            const url = window.URL.createObjectURL(blob);
            if (ventanaPdf) {
                ventanaPdf.location.href = url;
            } else {
                const a = document.createElement('a');
                a.href = url;
                a.download = `CP08_ComparativoGranjaGalpon_${Date.now()}.pdf`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            }
            setTimeout(() => window.URL.revokeObjectURL(url), 60000);
        } catch (error) {
            console.error('Error al exportar PDF CP08:', error);
            if (ventanaPdf) try { ventanaPdf.close(); } catch (e) {}
            alert(error.message || 'No se pudo generar el PDF de CP08.');
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.classList.remove('opacity-75', 'cursor-not-allowed');
                btn.innerHTML = originalHtml;
            }
        }
    },

    getSelectedFilters() {
        const filters = {};
        if (this.multiGranja) {
            const granjas = this.multiGranja.getSelectedValues();
            if (granjas.length > 0 && granjas.length < this.multiGranja.options.length) {
                filters.cencos = granjas;
            }
        }
        if (this.multiClasif) {
            const clasifs = this.multiClasif.getSelectedValues();
            if (clasifs.length > 0 && clasifs.length < this.multiClasif.options.length) {
                filters.clasificacion = clasifs;
            }
        }
        return filters;
    },

    aplicarOpcionesGranja(cencosList) {
        const optGranja = (cencosList || []).map(c => {
            const id = String(c.cencos).trim();
            const label = `${c.cencos} ${c.nomcencos || ''}`.trim();
            return { id: id, label: label, selected: true };
        });

        if (!this.multiGranja && typeof CustomMultiSelect !== 'undefined') {
            this.multiGranja = new CustomMultiSelect({
                btnId: 'btn-dropdown-granja-cp08',
                dropdownId: 'dropdown-granja-cp08',
                optionsContainerId: 'container-options-granja-cp08',
                labelId: 'label-granja-cp08',
                searchId: 'search-granja-cp08',
                title: 'Granja',
                options: optGranja,
                onChange: () => {
                    this.filtrarLocalmente();
                }
            });
        } else if (this.multiGranja) {
            this.multiGranja.setOptions(optGranja);
        }

        const labelGranja = document.getElementById('label-granja-cp08');
        if (optGranja.length === 0 && labelGranja) {
            labelGranja.textContent = '(Sin granjas en este período)';
            labelGranja.className = 'truncate text-slate-400 font-normal';
        }
    },

    actualizarGranjasDesdeCatalogo(fIni, fFin) {
        if (!this.catalogoGranjas || !Array.isArray(this.catalogoGranjas) || this.catalogoGranjas.length === 0) {
            return false;
        }

        const fIniStr = fIni.substring(0, 10);
        const fFinStr = fFin.substring(0, 10);
        const mIni = fIni.substring(0, 7);
        const mFin = fFin.substring(0, 7);

        const cencosFiltrados = this.catalogoGranjas.filter(g => {
            if (g.fechas_histo) {
                const arr = g.fechas_histo.split(',');
                for (let i = 0; i < arr.length; i++) {
                    const f = arr[i].trim();
                    const fm = f.substring(0, 7);
                    if ((f >= fIniStr && f <= fFinStr) || (fm >= mIni && fm <= mFin)) {
                        return true;
                    }
                }
            }
            if (g.f_min && g.f_max) {
                if (!(g.f_max < fIniStr || g.f_min > fFinStr)) return true;
            }
            return false;
        });

        this.aplicarOpcionesGranja(cencosFiltrados);
        return true;
    },

    setupFilters(data) {
        // Filtro Granja
        const contGranja = document.getElementById('contenedor-filtro-granja-cp08');
        if (contGranja) contGranja.classList.remove('hidden');

        const cencosDisp = (data && data.filtros_disponibles && data.filtros_disponibles.cencos) || [];
        this.aplicarOpcionesGranja(cencosDisp);

        // Filtro Clasificación
        const contClasif = document.getElementById('contenedor-filtro-clasificacion-cp08');
        if (contClasif) contClasif.classList.remove('hidden');

        const clasifsDisp = (data.filtros_disponibles && data.filtros_disponibles.clasificaciones) || [];
        if (typeof CustomMultiSelect !== 'undefined' && clasifsDisp.length > 0) {
            const optClasif = clasifsDisp.map(c => {
                const id = (c.clasificacion || `${c.linea} ${c.nomlinea}`).trim();
                return { id: id, label: id, selected: true };
            });

            if (!this.multiClasif) {
                this.multiClasif = new CustomMultiSelect({
                    btnId: 'btn-dropdown-clasificacion-cp08',
                    dropdownId: 'dropdown-clasificacion-cp08',
                    optionsContainerId: 'container-options-clasificacion-cp08',
                    labelId: 'label-clasificacion-cp08',
                    searchId: 'search-clasificacion-cp08',
                    title: 'Clasificación',
                    options: optClasif,
                    onChange: () => {
                        this.filtrarLocalmente();
                    }
                });
            } else {
                this.multiClasif.setOptions(optClasif);
            }
        }
    },

    async onFechasChanged(rango) {
        if (!rango || (!rango.fechaInicio && !rango.fechaFin)) return;

        const fIni = rango.fechaInicio || rango.inicio;
        const fFin = rango.fechaFin || rango.fin;
        if (!fIni || !fFin) return;

        // 1. Filtrado instantáneo (0ms) en cliente si ya tenemos el catálogo
        const filtradoInstantaneo = this.actualizarGranjasDesdeCatalogo(fIni, fFin);

        const labelGranja = document.getElementById('label-granja-cp08');
        const prevText = labelGranja ? labelGranja.textContent : '';

        // Solo mostrar indicador sutil si no tenemos catálogo aún
        if (!filtradoInstantaneo && labelGranja) {
            labelGranja.textContent = 'Actualizando...';
        }

        try {
            const baseUrl = (typeof AppConfig !== 'undefined' && AppConfig.API && AppConfig.API.BASE_URL) 
                ? AppConfig.API.BASE_URL 
                : (window.costoDiarioController?.service?.baseUrl || '../../backend');
            const url = `${baseUrl}/costoDiario/dashboard`;

            const res = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    tipo_grafico: 'CP08 ComparativoGranjaGalpon',
                    fecha_inicio: fIni,
                    fecha_fin: fFin,
                    solo_filtros: true
                })
            });

            if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
            const dataRes = await res.json();
            const data = dataRes.payload || dataRes.data || dataRes;

            if (data && data.filtros_disponibles) {
                if (data.filtros_disponibles.granjas_catalogo) {
                    this.catalogoGranjas = data.filtros_disponibles.granjas_catalogo;
                }

                const cencosDisp = data.filtros_disponibles.cencos || [];
                this.aplicarOpcionesGranja(cencosDisp);

                const clasifsDisp = data.filtros_disponibles.clasificaciones || [];
                if (typeof CustomMultiSelect !== 'undefined' && clasifsDisp.length > 0 && this.multiClasif) {
                    const optClasif = clasifsDisp.map(c => {
                        const id = (c.clasificacion || `${c.linea} ${c.nomlinea}`).trim();
                        return { id: id, label: id, selected: true };
                    });
                    this.multiClasif.setOptions(optClasif);
                }
            }
        } catch (err) {
            console.error('Error al actualizar opciones de granja en CP08:', err);
            if (!filtradoInstantaneo && labelGranja) {
                labelGranja.textContent = prevText || '(Todo)';
            }
        }
    },

    filtrarLocalmente() {
        if (this.multiGranja) {
            const granjas = this.multiGranja.getSelectedValues();
            const totalOpciones = this.multiGranja.options ? this.multiGranja.options.length : 0;

            if (granjas.length > 0 && granjas.length < totalOpciones) {
                const cencosAntes = this.obtenerCencosSeleccionados().join('|');

                this.galponesSeleccionados = this.galponesSeleccionados.filter(item =>
                    granjas.includes(String(item.cencos))
                );

                if (!this.galponesSeleccionados.length && this.cencosActivo && !granjas.includes(String(this.cencosActivo))) {
                    this.cencosActivo = granjas[0];
                    this.nomcencosActivo = this.nombreCencos(granjas[0]);
                }

                const cencosDespues = this.obtenerCencosSeleccionados().join('|');

                if (cencosAntes !== cencosDespues) {
                    this.lineasSeleccionadas = [];
                }

                this.sincronizarSeleccionSimple();
            }
        }

        this.asegurarDatosCencos();
    },

    claveGalpon(cencos, galpon) {
        return `${String(cencos)}||${String(galpon)}`;
    },

    claveLinea(linea, nomlinea) {
        return `${String(linea)}||${String(nomlinea || '')}`;
    },

    galponEstaSeleccionado(cencos, galpon) {
        const clave = this.claveGalpon(cencos, galpon);
        return this.galponesSeleccionados.some(item => this.claveGalpon(item.cencos, item.galpon) === clave);
    },

    lineaEstaSeleccionada(linea, nomlinea) {
        return this.lineasSeleccionadas.includes(this.claveLinea(linea, nomlinea));
    },

    sincronizarSeleccionSimple() {
        const ultimoGalpon = this.galponesSeleccionados[this.galponesSeleccionados.length - 1] || null;
        this.galponActivo = ultimoGalpon ? String(ultimoGalpon.galpon) : null;

        const ultimaClaveLinea = this.lineasSeleccionadas[this.lineasSeleccionadas.length - 1] || null;
        this.lineaSeleccionada = ultimaClaveLinea ? String(ultimaClaveLinea).split('||')[0] : null;
    },

    obtenerCencosSeleccionados() {
        if (!this.galponesSeleccionados.length) {
            return this.cencosActivo ? [String(this.cencosActivo)] : [];
        }

        return Array.from(new Set(this.galponesSeleccionados.map(item => String(item.cencos)))).sort();
    },

    clasificacionCoincide(fila) {
        const selectedClasif = this.multiClasif ? this.multiClasif.getSelectedValues() : [];

        if (!selectedClasif || selectedClasif.length === 0) return true;

        const totalOpciones = this.multiClasif && this.multiClasif.options ? this.multiClasif.options.length : 0;

        if (totalOpciones > 0 && selectedClasif.length >= totalOpciones) return true;

        const linea = String((fila && fila.linea) || '');
        const clasifStr = `${linea} ${(fila && fila.nomlinea) || ''}`.trim();

        return selectedClasif.some(sel => sel === linea || sel === clasifStr || sel.startsWith(linea));
    },

    obtenerGruposPaneles() {
        const cencosList = this.obtenerCencosSeleccionados();

        return cencosList.map(cen => {
            const cache = this.datosPorCencos[String(cen)];

            if (!cache) return null;

            let galpones2 = (cache.tabla2 && cache.tabla2.galpones_headers) || [];
            let galpones3 = (cache.tabla3 && cache.tabla3.galpones_headers) || [];

            if (this.galponesSeleccionados.length) {
                const seleccionados = this.galponesSeleccionados
                    .filter(item => String(item.cencos) === String(cen))
                    .map(item => String(item.galpon));

                if (seleccionados.length) {
                    galpones2 = galpones2.filter(g => seleccionados.includes(String(g)));
                    galpones3 = galpones3.filter(g => seleccionados.includes(String(g)));
                }
            }

            return {
                cencos: String(cen),
                nomcencos: cache.nomcencos || '',
                tabla2: cache.tabla2 || {},
                tabla3: cache.tabla3 || {},
                galpones2,
                galpones3
            };
        }).filter(Boolean);
    },

    nombreCencos(cencos) {
        const cache = this.datosPorCencos[String(cencos)];

        if (cache && cache.nomcencos) return cache.nomcencos;

        const granja = (this.datosBackend.tabla1_datos_productivos?.granjas || [])
            .find(item => String(item.cencos) === String(cencos));

        return granja ? granja.nomcencos : '';
    },

    obtenerDatosCencos(cencos) {
        const key = String(cencos);
        const generacion = this.generacionDatos || 0;

        if (this.datosPorCencos[key]) {
            return Promise.resolve(this.datosPorCencos[key]);
        }

        if (this.promesasCencos[key]) {
            return this.promesasCencos[key];
        }

        let rango = {};
        if (typeof PeriodoHelper !== 'undefined' && PeriodoHelper.obtenerRangoFechas) {
            rango = PeriodoHelper.obtenerRangoFechas();
        }

        const payload = {
            tipo_grafico: 'CP08 ComparativoGranjaGalpon',
            fecha_inicio: rango.fechaInicio || rango.inicio,
            fecha_fin: rango.fechaFin || rango.fin,
            fechahisto: this.datosBackend.fecha,
            cencos_seleccionado: key
        };

        if (this.multiGranja) {
            const granjas = this.multiGranja.getSelectedValues();
            if (granjas.length > 0 && granjas.length < this.multiGranja.options.length) {
                payload.cencos = granjas.join(',');
            }
        }

        if (this.multiClasif) {
            const clasifs = this.multiClasif.getSelectedValues();
            if (clasifs.length > 0 && clasifs.length < this.multiClasif.options.length) {
                payload.clasificacion = clasifs.join(',');
            }
        }

        const baseUrl = (typeof AppConfig !== 'undefined' && AppConfig.API && AppConfig.API.BASE_URL)
            ? AppConfig.API.BASE_URL
            : '../../backend';

        const promesa = fetch(`${baseUrl}/costoDiario/dashboard`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(res => {
                if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
                return res.json();
            })
            .then(res => {
                const data = res.payload || res.data || res || {};
                const cache = {
                    tabla2: data.tabla2_comparacion_linea || {},
                    tabla3: data.tabla3_comparativo_detalle || {},
                    nomcencos: data.nomcencos_activo || this.nombreCencos(key)
                };

                if (generacion !== (this.generacionDatos || 0)) {
                    return cache;
                }

                this.datosPorCencos[key] = cache;

                if (String(key) === String(this.cencosActivo)) {
                    this.datosBackend.tabla2_comparacion_linea = cache.tabla2;
                    this.datosBackend.tabla3_comparativo_detalle = cache.tabla3;
                    this.datosBackend.cencos_activo = key;
                    this.datosBackend.nomcencos_activo = cache.nomcencos;
                }

                return cache;
            })
            .catch(err => {
                console.error('Error al recargar datos de campaña CP08:', err);
                const cache = { tabla2: {}, tabla3: {}, nomcencos: this.nombreCencos(key) };

                if (generacion === (this.generacionDatos || 0)) {
                    this.datosPorCencos[key] = cache;
                }

                return cache;
            })
            .finally(() => {
                if (this.promesasCencos[key] === promesa) {
                    delete this.promesasCencos[key];
                }
            });

        this.promesasCencos[key] = promesa;

        return promesa;
    },

    async asegurarDatosCencos() {
        const cencos = this.obtenerCencosSeleccionados();
        const faltantes = cencos.filter(cen => !this.datosPorCencos[String(cen)]);

        if (!faltantes.length) {
            this.renderPanel1();
            this.renderPanel2();
            this.renderPanel3();
            return;
        }

        const secuencia = ++this.cargaSeq;
        await Promise.all(faltantes.map(cen => this.obtenerDatosCencos(cen)));

        if (secuencia !== this.cargaSeq) return;

        this.renderPanel1();
        this.renderPanel2();
        this.renderPanel3();
    },

    renderLayout() {
        const contenedor = document.getElementById('contenedor-grafica-costo');
        if (!contenedor) return;

        contenedor.className = "flex flex-col w-full p-2 bg-slate-50/50 gap-6";
        contenedor.innerHTML = `
            <div class="w-full flex flex-col gap-5 text-slate-800 font-sans">

                <!-- FILA SUPERIOR: Panel 1 (Datos Productivos) y Panel 2 (Comparación Línea) -->
                <div class="grid grid-cols-1 xl:grid-cols-12 gap-5 items-start">
                    
                    <!-- PANEL 1: Datos Productivos -->
                    <div class="xl:col-span-5 flex flex-col bg-white border border-slate-300 rounded-xl shadow-xs overflow-hidden">
                        <div class="px-4 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                            <h3 class="text-xs sm:text-sm font-bold text-slate-800 uppercase tracking-wide">Datos Productivos</h3>
                            <div class="flex items-center gap-2">
                                <span id="cp08-badge-p1" class="text-[11px] font-semibold text-slate-500 bg-white px-2.5 py-1 rounded border border-slate-200 whitespace-nowrap">
                                    0 Granjas
                                </span>
                                <button id="cp08-btn-export-p1" type="button"
                                    class="flex items-center gap-1.5 px-2 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 active:bg-emerald-200 border border-emerald-300 rounded-lg transition-all cursor-pointer shadow-2xs">
                                    <svg class="w-3.5 h-3.5 text-emerald-600 shrink-0" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM6 20V4h7v5h5v11H6z"/>
                                        <path d="M8.5 17.5l2.25-3.5L8.5 10.5h1.75l1.375 2.25 1.375-2.25h1.75l-2.25 3.5 2.25 3.5h-1.75L11.625 15.25 10.25 17.5z"/>
                                    </svg>
                                    <span>Excel</span>
                                </button>
                            </div>
                        </div>

                        <div id="cp08-container-tabla-p1" class="w-full overflow-x-auto max-h-[460px] custom-scrollbar">
                            <table id="cp08-tabla-p1" class="w-full text-xs border-collapse select-none">
                                <thead class="sticky top-0 z-20 bg-blue-600 text-white border-b border-slate-300 font-bold text-center shadow-xs">
                                    <tr>
                                        <th class="px-2 py-2 border-r border-slate-200">cencos</th>
                                        <th class="px-1.5 py-2 border-r border-slate-200">galpon</th>
                                        <th class="px-2.5 py-2 text-right border-r border-slate-200">UnidadesVen..</th>
                                        <th class="px-2.5 py-2 text-right border-r border-slate-200">KilosVendidos</th>
                                        <th class="px-2 py-2 text-right border-r border-slate-200">PesoPromedio</th>
                                        <th class="px-2 py-2 text-right border-r border-slate-200">ICA</th>
                                        <th class="px-2 py-2 text-right border-r border-slate-200">PromEdadVen..</th>
                                        <th class="px-2 py-2 text-right border-r border-slate-200">%Mortalidad</th>
                                        <th class="px-2 py-2 text-right">PGD</th>
                                    </tr>
                                </thead>
                                <tbody id="cp08-tbody-p1" class="divide-y divide-slate-100 text-slate-800"></tbody>
                                <tfoot id="cp08-tfoot-p1" class="sticky bottom-0 z-20 bg-slate-100 border-t-2 border-slate-300 font-bold text-slate-900 shadow-md"></tfoot>
                            </table>
                        </div>
                    </div>

                    <!-- PANEL 2: Comparación Línea -->
                    <div class="xl:col-span-7 flex flex-col bg-white border border-slate-300 rounded-xl shadow-xs overflow-hidden">
                        <div class="px-4 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                            <h3 class="text-xs sm:text-sm font-bold text-slate-800 uppercase tracking-wide">Comparacion Linea</h3>
                            <div class="flex items-center gap-2">
                                <span id="cp08-badge-p2" class="text-[11px] font-semibold text-slate-500 bg-white px-2.5 py-1 rounded border border-slate-200 whitespace-nowrap">
                                    0 Líneas
                                </span>
                                <button id="cp08-btn-export-p2" type="button"
                                    class="flex items-center gap-1.5 px-2 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 active:bg-emerald-200 border border-emerald-300 rounded-lg transition-all cursor-pointer shadow-2xs">
                                    <svg class="w-3.5 h-3.5 text-emerald-600 shrink-0" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM6 20V4h7v5h5v11H6z"/>
                                        <path d="M8.5 17.5l2.25-3.5L8.5 10.5h1.75l1.375 2.25 1.375-2.25h1.75l-2.25 3.5 2.25 3.5h-1.75L11.625 15.25 10.25 17.5z"/>
                                    </svg>
                                    <span>Excel</span>
                                </button>
                            </div>
                        </div>

                        <div class="w-full overflow-x-auto max-h-[460px] custom-scrollbar" id="cp08-container-tabla-p2">
                            <!-- Tabla 2 se renderiza dinámicamente con cabeceras pivotadas de galpones -->
                        </div>
                    </div>

                </div>

                <!-- FILA INFERIOR: Panel 3 (Comparativo Detalle Productos) -->
                <div class="w-full flex flex-col bg-white border border-slate-300 rounded-xl shadow-xs overflow-hidden">
                    <div class="px-4 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                        <div class="flex items-center gap-3">
                            <h3 class="text-xs sm:text-sm font-bold text-slate-800 uppercase tracking-wide">Comparativo Detalle Productos</h3>
                            <span id="cp08-badge-linea-filtro" class="hidden text-[11px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-300 cursor-pointer" title="Clic para quitar filtro">
                                Línea: - ✕
                            </span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span id="cp08-badge-p3" class="text-[11px] font-semibold text-slate-500 bg-white px-2.5 py-1 rounded border border-slate-200 whitespace-nowrap">
                                0 Productos
                            </span>
                            <button id="cp08-btn-export-p3" type="button"
                                class="flex items-center gap-1.5 px-2 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 active:bg-emerald-200 border border-emerald-300 rounded-lg transition-all cursor-pointer shadow-2xs">
                                <svg class="w-3.5 h-3.5 text-emerald-600 shrink-0" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM6 20V4h7v5h5v11H6z"/>
                                    <path d="M8.5 17.5l2.25-3.5L8.5 10.5h1.75l1.375 2.25 1.375-2.25h1.75l-2.25 3.5 2.25 3.5h-1.75L11.625 15.25 10.25 17.5z"/>
                                </svg>
                                <span>Excel</span>
                            </button>
                        </div>
                    </div>

                    <div class="w-full overflow-x-auto max-h-[500px] custom-scrollbar" id="cp08-container-tabla-p3">
                        <!-- Tabla 3 se renderiza dinámicamente con cabeceras pivotadas de galpones -->
                    </div>
                </div>

            </div>
        `;

        document.getElementById('cp08-badge-linea-filtro')?.addEventListener('click', () => {
            this.lineasSeleccionadas = [];
            this.sincronizarSeleccionSimple();
            this.renderPanel2();
            this.renderPanel3();
        });

        // Configuración de exportación a Excel para las 3 tablas de CP08
        const fechaNom = (this.datosBackend.fecha_formateada || this.datosBackend.fecha || 'general').replace(/[^a-zA-Z0-9]/g, '_');

        const btnP1 = document.getElementById('cp08-btn-export-p1');
        if (btnP1) {
            btnP1.onclick = () => {
                if (typeof ExcelExportHelper !== 'undefined') {
                    ExcelExportHelper.exportarTabla('cp08-tabla-p1', `CP08_Datos_Productivos_${fechaNom}`);
                }
            };
        }

        const btnP2 = document.getElementById('cp08-btn-export-p2');
        if (btnP2) {
            btnP2.onclick = () => {
                if (typeof ExcelExportHelper !== 'undefined') {
                    const sufijoCencos = this.cencosActivo ? `_${this.cencosActivo}` : '';
                    const sufijoGalp = this.galponActivo ? `_G${this.galponActivo}` : '';
                    ExcelExportHelper.exportarTabla('cp08-tabla-p2', `CP08_Comparacion_Linea${sufijoCencos}${sufijoGalp}_${fechaNom}`);
                }
            };
        }

        const btnP3 = document.getElementById('cp08-btn-export-p3');
        if (btnP3) {
            btnP3.onclick = () => {
                if (typeof ExcelExportHelper !== 'undefined') {
                    const sufijoCencos = this.cencosActivo ? `_${this.cencosActivo}` : '';
                    const sufijoGalp = this.galponActivo ? `_G${this.galponActivo}` : '';
                    const sufijoLinea = this.lineaSeleccionada ? `_L${this.lineaSeleccionada}` : '';
                    ExcelExportHelper.exportarTabla('cp08-tabla-p3', `CP08_Comparativo_Detalle_Productos${sufijoCencos}${sufijoGalp}${sufijoLinea}_${fechaNom}`);
                }
            };
        }

        this.renderPanel1();
        this.renderPanel2();
        this.renderPanel3();
        this.bindAutoClearPanels();
    },

    _capturarScroll(el) {
        return el ? { top: el.scrollTop, left: el.scrollLeft } : null;
    },

    _restaurarScroll(el, estado) {
        if (!el || !estado) return;
        el.scrollTop = estado.top;
        el.scrollLeft = estado.left;
    },

    _clicEnScrollbar(e, el) {
        if (!el) return false;
        const rect = el.getBoundingClientRect();
        const scrollbarVertical = el.offsetWidth - el.clientWidth;
        const scrollbarHorizontal = el.offsetHeight - el.clientHeight;

        if (scrollbarVertical > 0 && e.clientX >= rect.left + el.clientWidth) return true;
        if (scrollbarHorizontal > 0 && e.clientY >= rect.top + el.clientHeight) return true;

        return false;
    },

    bindAutoClearPanels() {
        const panel1 = document.getElementById('cp08-container-tabla-p1');
        if (panel1 && !panel1._cp08AutoClear) {
            panel1._cp08AutoClear = true;
            panel1.addEventListener('click', (e) => {
                if (e.target.closest('tr, button, input, a, select, textarea')) return;
                if (this._clicEnScrollbar(e, panel1)) return;
                if (!this.galponesSeleccionados.length) return;

                this.galponesSeleccionados = [];
                this.sincronizarSeleccionSimple();
                this.asegurarDatosCencos();
            });
        }

        const panel2 = document.getElementById('cp08-container-tabla-p2');
        if (panel2 && !panel2._cp08AutoClear) {
            panel2._cp08AutoClear = true;
            panel2.addEventListener('click', (e) => {
                if (e.target.closest('tr, button, input, a, select, textarea')) return;
                if (this._clicEnScrollbar(e, panel2)) return;
                if (!this.lineasSeleccionadas.length) return;

                this.lineasSeleccionadas = [];
                this.sincronizarSeleccionSimple();
                this.renderPanel2();
                this.renderPanel3();
            });
        }
    },

    renderPanel1() {
        const tbody = document.getElementById('cp08-tbody-p1');
        const tfoot = document.getElementById('cp08-tfoot-p1');
        const badge = document.getElementById('cp08-badge-p1');
        if (!tbody || !tfoot) return;

        const contenedorP1 = document.getElementById('cp08-container-tabla-p1');
        const scrollP1 = this._capturarScroll(contenedorP1);

        const allGranjas = (this.datosBackend.tabla1_datos_productivos && this.datosBackend.tabla1_datos_productivos.granjas) || [];
        const selectedGranjas = this.multiGranja ? this.multiGranja.getSelectedValues() : [];
        const isFilteringGranja = selectedGranjas && selectedGranjas.length > 0 && selectedGranjas.length < (this.multiGranja.options ? this.multiGranja.options.length : 999);

        let granjasFiltradas = allGranjas.filter(g => {
            if (isFilteringGranja && !selectedGranjas.includes(g.cencos)) return false;
            return true;
        });

        if (badge) badge.textContent = `${granjasFiltradas.length} Granjas`;

        if (granjasFiltradas.length === 0) {
            tbody.innerHTML = `<tr><td colspan="9" class="py-8 text-center text-slate-400 italic">No hay datos productivos para los filtros seleccionados</td></tr>`;
            tfoot.innerHTML = '';
            return;
        }

        let rowsHtml = '';

        granjasFiltradas.forEach(g => {
            const isGranjaActiva = this.cencosActivo === g.cencos;
            const galpones = g.galpones || [];

            galpones.forEach((r, idx) => {
                const isFirstRow = idx === 0;
                const cencosDisplay = isFirstRow ? `<span class="font-bold text-slate-800 font-mono">${r.cencos}</span>` : '';
                
                // Resaltado de selección cruzada
                const isRowSelected = this.galponEstaSeleccionado(r.cencos, r.galpon);
                const sinSeleccionGalpon = this.galponesSeleccionados.length === 0;
                const rowBgClass = isRowSelected
                    ? 'bg-sky-200 font-bold text-blue-950 border-l-4 border-l-blue-600'
                    : (sinSeleccionGalpon && isGranjaActiva ? 'bg-blue-50/60 hover:bg-blue-100/60' : 'hover:bg-slate-50');

                rowsHtml += `
                    <tr class="cp08-row-p1 ${rowBgClass} cursor-pointer transition-colors border-t border-slate-100"
                        data-cencos="${r.cencos}" data-nomcencos="${r.nomcencos}" data-galpon="${r.galpon}"
                        data-und="${r.unidades_ven}" data-kilos="${r.kilos_vendidos}" data-peso="${r.peso_promedio}"
                        data-ica="${r.ica}" data-edad="${r.prom_edad_ven}" data-mort="${r.porc_mort}" data-pgd="${r.pgd}">
                        <td class="px-2 py-1 text-center font-mono border-r border-slate-100 select-none">${cencosDisplay}</td>
                        <td class="px-1.5 py-1 text-center font-mono text-slate-700 border-r border-slate-100">${r.galpon}</td>
                        <td class="px-2.5 py-1 text-right font-mono border-r border-slate-100" data-metric="UnidadesVendidas" data-val="${this.formatNum(r.unidades_ven, 0)}">${this.formatNum(r.unidades_ven, 0)}</td>
                        <td class="px-2.5 py-1 text-right font-mono border-r border-slate-100" data-metric="KilosVendidos" data-val="${this.formatNum(r.kilos_vendidos, 2)}">${this.formatNum(r.kilos_vendidos, 2)}</td>
                        <td class="px-2 py-1 text-right font-mono border-r border-slate-100 font-medium" data-metric="PesoPromedio" data-val="${this.formatNum(r.peso_promedio, 3)}">${this.formatNum(r.peso_promedio, 3)}</td>
                        <td class="px-2 py-1 text-right font-mono border-r border-slate-100" data-metric="ICA" data-val="${this.formatNum(r.ica, 3)}">${this.formatNum(r.ica, 3)}</td>
                        <td class="px-2 py-1 text-right font-mono border-r border-slate-100" data-metric="PromEdadVen" data-val="${this.formatNum(r.prom_edad_ven, 3)}">${this.formatNum(r.prom_edad_ven, 3)}</td>
                        <td class="px-2 py-1 text-right font-mono border-r border-slate-100 text-slate-700" data-metric="%Mortalidad" data-val="${this.formatNum(r.porc_mort, 3)}%">${this.formatNum(r.porc_mort, 3)}</td>
                        <td class="px-2 py-1 text-right font-mono text-slate-900 font-semibold" data-metric="PGD" data-val="${this.formatNum(r.pgd, 3)}">${this.formatNum(r.pgd, 3)}</td>
                    </tr>
                `;
            });

            // Subtotal de la Granja
            const sub = g.subtotal || {};
            const isSubSelected = (isGranjaActiva && this.galponesSeleccionados.length === 0);
            const subBgClass = isSubSelected
                ? 'bg-sky-100 font-bold text-blue-900 border-t border-b border-blue-300'
                : 'bg-slate-50 font-bold hover:bg-slate-100';

            rowsHtml += `
                <tr class="${subBgClass} border-t border-b border-slate-300 text-slate-900 text-[11px] select-none cursor-pointer cp08-row-p1-total"
                    data-cencos="${g.cencos}" data-nomcencos="${g.nomcencos}">
                    <td class="px-2 py-1 text-center font-mono border-r border-slate-200"></td>
                    <td class="px-1.5 py-1 text-center font-bold border-r border-slate-200 uppercase">Total</td>
                    <td class="px-2.5 py-1 text-right font-mono border-r border-slate-200" data-metric="Total Unidades" data-val="${this.formatNum(sub.unidades_ven, 0)}">${this.formatNum(sub.unidades_ven, 0)}</td>
                    <td class="px-2.5 py-1 text-right font-mono border-r border-slate-200" data-metric="Total Kilos" data-val="${this.formatNum(sub.kilos_vendidos, 2)}">${this.formatNum(sub.kilos_vendidos, 2)}</td>
                    <td class="px-2 py-1 text-right font-mono border-r border-slate-200" data-metric="Peso Promedio Total" data-val="${this.formatNum(sub.peso_promedio, 3)}">${this.formatNum(sub.peso_promedio, 3)}</td>
                    <td class="px-2 py-1 text-right font-mono border-r border-slate-200" data-metric="ICA Total" data-val="${this.formatNum(sub.ica, 3)}">${this.formatNum(sub.ica, 3)}</td>
                    <td class="px-2 py-1 text-right font-mono border-r border-slate-200" data-metric="Prom Edad Total" data-val="${this.formatNum(sub.prom_edad_ven, 3)}">${this.formatNum(sub.prom_edad_ven, 3)}</td>
                    <td class="px-2 py-1 text-right font-mono border-r border-slate-200" data-metric="Mortalidad Total" data-val="${this.formatNum(sub.porc_mort, 3)}%">${this.formatNum(sub.porc_mort, 3)}</td>
                    <td class="px-2 py-1 text-right font-mono font-bold" data-metric="PGD Total" data-val="${this.formatNum(sub.pgd, 3)}">${this.formatNum(sub.pgd, 3)}</td>
                </tr>
            `;
        });

        tbody.innerHTML = rowsHtml;

        // Total General
        const totGen = this.datosBackend.tabla1_datos_productivos?.total_general || {};
        tfoot.innerHTML = `
            <tr class="border-t-2 border-slate-300">
                <td class="px-2 py-1.5 text-center border-r border-slate-200 font-bold uppercase" colspan="2">Total General</td>
                <td class="px-2.5 py-1.5 text-right font-mono font-bold text-slate-800 border-r border-slate-200">${this.formatNum(totGen.unidades_ven, 0)}</td>
                <td class="px-2.5 py-1.5 text-right font-mono font-bold text-slate-800 border-r border-slate-200">${this.formatNum(totGen.kilos_vendidos, 2)}</td>
                <td class="px-2 py-1.5 text-right font-mono font-bold text-slate-800 border-r border-slate-200">${this.formatNum(totGen.peso_promedio, 3)}</td>
                <td class="px-2.5 py-1.5 text-right font-mono font-bold text-slate-800 border-r border-slate-200">${this.formatNum(totGen.ica, 3)}</td>
                <td class="px-2.5 py-1.5 text-right font-mono font-bold text-slate-800 border-r border-slate-200">${this.formatNum(totGen.prom_edad_ven, 3)}</td>
                <td class="px-2.5 py-1.5 text-right font-mono font-bold text-slate-800 border-r border-slate-200">${this.formatNum(totGen.porc_mort, 3)}</td>
                <td class="px-2.5 py-1.5 text-right font-mono font-bold text-blue-700">${this.formatNum(totGen.pgd, 3)}</td>
            </tr>
        `;

        this.bindPanel1Events();
        this._restaurarScroll(contenedorP1, scrollP1);
    },

    bindPanel1Events() {
        const self = this;
        const rows = document.querySelectorAll('.cp08-row-p1');

        rows.forEach(tr => {
            tr.addEventListener('click', function(e) {
                const cencos = this.getAttribute('data-cencos');
                const galpon = this.getAttribute('data-galpon');
                const nomcencos = this.getAttribute('data-nomcencos');
                const clave = self.claveGalpon(cencos, galpon);
                const conCtrl = e.ctrlKey || e.metaKey;
                const cencosAntes = self.obtenerCencosSeleccionados().join('|');

                if (conCtrl) {
                    const indice = self.galponesSeleccionados.findIndex(item =>
                        self.claveGalpon(item.cencos, item.galpon) === clave
                    );

                    if (indice >= 0) {
                        self.galponesSeleccionados.splice(indice, 1);
                    } else {
                        self.galponesSeleccionados.push({ cencos, galpon, nomcencos });
                    }
                } else {
                    const soloEste = self.galponesSeleccionados.length === 1 &&
                        self.claveGalpon(self.galponesSeleccionados[0].cencos, self.galponesSeleccionados[0].galpon) === clave;

                    self.galponesSeleccionados = soloEste ? [] : [{ cencos, galpon, nomcencos }];
                }

                // La granja activa solo debe cambiar cuando hay una selección.
                // Al deseleccionar se conserva la granja activa previa para volver al estado anterior.
                const ultimoSeleccionado = self.galponesSeleccionados[self.galponesSeleccionados.length - 1];
                if (ultimoSeleccionado) {
                    self.cencosActivo = ultimoSeleccionado.cencos;
                    self.nomcencosActivo = ultimoSeleccionado.nomcencos;
                }

                const cencosDespues = self.obtenerCencosSeleccionados().join('|');

                if (cencosAntes !== cencosDespues) {
                    self.lineasSeleccionadas = [];
                }

                self.sincronizarSeleccionSimple();
                self.renderPanel1();
                self.asegurarDatosCencos();
            });

            tr.addEventListener('mouseenter', function(e) {
                const cencos = this.getAttribute('data-cencos');
                const nomcencos = this.getAttribute('data-nomcencos');
                const galpon = this.getAttribute('data-galpon');
                const und = this.getAttribute('data-und');

                self.showTooltip(e, {
                    'cencos': cencos,
                    'galpon': galpon,
                    'fecha': self.datosBackend.fecha_formateada || self.datosBackend.fecha,
                    'nomcencos': nomcencos,
                    'UnidadesVendidas': self.formatNum(und, 0)
                });
            });

            tr.addEventListener('mousemove', function(e) {
                self.moveTooltip(e);
            });

            tr.addEventListener('mouseleave', function() {
                self.hideTooltip();
            });
        });

        // Click en fila de Total de la Granja
        const rowsTotal = document.querySelectorAll('.cp08-row-p1-total');
        rowsTotal.forEach(tr => {
            tr.addEventListener('click', function() {
                const cencos = this.getAttribute('data-cencos');
                const nomcencos = this.getAttribute('data-nomcencos');

                self.cencosActivo = cencos;
                self.nomcencosActivo = nomcencos;
                self.galponesSeleccionados = [];
                self.lineasSeleccionadas = [];
                self.sincronizarSeleccionSimple();
                self.renderPanel1();
                self.asegurarDatosCencos();
            });
        });
    },

    recargarDatosGranjaActiva() {
        this.asegurarDatosCencos();
    },

    renderPanel2() {
        const container = document.getElementById('cp08-container-tabla-p2');
        const badgeP2 = document.getElementById('cp08-badge-p2');
        if (!container) return;

        const scrollP2 = this._capturarScroll(container);

        const grupos = this.obtenerGruposPaneles()
            .map(grupo => ({ ...grupo, galpones: grupo.galpones2 || [] }))
            .filter(grupo => grupo.galpones.length > 0);

        if (!grupos.length) {
            if (badgeP2) badgeP2.textContent = '0 Líneas';
            container.innerHTML = `<div class="p-8 text-center text-slate-400 italic">No hay datos de líneas para las campañas seleccionadas</div>`;
            return;
        }

        const lineasMap = new Map();

        grupos.forEach(grupo => {
            const filasGrupo = (grupo.tabla2.filas || []).filter(r => this.clasificacionCoincide(r));

            filasGrupo.forEach(r => {
                const key = `${r.linea}||${r.nomlinea || ''}`;

                if (!lineasMap.has(key)) {
                    lineasMap.set(key, {
                        linea: r.linea,
                        nomlinea: r.nomlinea || '',
                        porGrupo: {}
                    });
                }

                lineasMap.get(key).porGrupo[grupo.cencos] = r;
            });
        });

        const filas = Array.from(lineasMap.values());

        if (badgeP2) badgeP2.textContent = `${filas.length} Líneas`;

        if (!filas.length) {
            container.innerHTML = `<div class="p-8 text-center text-slate-400 italic">No hay datos de líneas para las campañas seleccionadas</div>`;
            return;
        }

        let headerRow0 = `
            <tr>
                <th class="px-2 py-2 border-r border-slate-200" rowspan="3">linea</th>
                <th class="px-2.5 py-2 text-left border-r border-slate-200" rowspan="3">nomlinea</th>
        `;
        let headerRow1 = `<tr>`;
        let headerRow2 = `<tr>`;

        grupos.forEach(grupo => {
            headerRow0 += `<th class="px-2 py-1 border-r border-slate-200 bg-blue-800 text-center font-bold" colspan="${grupo.galpones.length * 4}" title="${grupo.nomcencos || ''}">${grupo.cencos}</th>`;

            grupo.galpones.forEach(g => {
                headerRow1 += `<th class="px-2 py-1 border-r border-slate-200 bg-blue-700 text-center font-bold" colspan="4">${g}</th>`;
                headerRow2 += `
                    <th class="px-2 py-1 text-right border-r border-slate-200 text-[11px]">valor</th>
                    <th class="px-2 py-1 text-right border-r border-slate-200 text-[11px]">Kilos Producid..</th>
                    <th class="px-2 py-1 text-right border-r border-slate-200 text-[11px]">CU</th>
                    <th class="px-2 py-1 text-right border-r border-slate-200 text-[11px]">Dif en CU</th>
                `;
            });
        });

        headerRow0 += `</tr>`;
        headerRow1 += `</tr>`;
        headerRow2 += `</tr>`;

        let rowsHtml = '';

        filas.forEach(r => {
            const isSelected = this.lineaEstaSeleccionada(r.linea, r.nomlinea);
            const rowClass = isSelected
                ? 'bg-sky-200 font-bold text-blue-950 border-l-4 border-l-blue-600'
                : 'hover:bg-slate-50 cursor-pointer';

            rowsHtml += `
                <tr class="cp08-row-p2 ${rowClass} transition-colors border-t border-slate-100"
                    data-linea="${r.linea}" data-nomlinea="${r.nomlinea || ''}">
                    <td class="px-2 py-1 text-center font-mono font-bold text-slate-700 border-r border-slate-100">${r.linea}</td>
                    <td class="px-2.5 py-1 text-left font-mono border-r border-slate-100 whitespace-nowrap text-[11px]">${r.nomlinea || ''}</td>
            `;

            grupos.forEach(grupo => {
                const filaGrupo = r.porGrupo[grupo.cencos] || null;

                grupo.galpones.forEach(g => {
                    const gData = (filaGrupo && filaGrupo.galpones && filaGrupo.galpones[g]) || null;

                    if (gData) {
                        const difCuClass = gData.dif_cu > 0 ? 'text-rose-600' : (gData.dif_cu < 0 ? 'text-emerald-600' : 'text-slate-400');
                        rowsHtml += `
                            <td class="px-2 py-1 text-right font-mono border-r border-slate-100 cp08-cell-p2"
                                data-galpon="${g}" data-metric="valor" data-val="${this.formatNum(gData.valor, 2)}">${this.formatNum(gData.valor, 2)}</td>
                            <td class="px-2 py-1 text-right font-mono border-r border-slate-100 text-slate-600 cp08-cell-p2"
                                data-galpon="${g}" data-metric="Kilos Producidos" data-val="${this.formatNum(gData.kilos, 2)}">${this.formatNum(gData.kilos, 2)}</td>
                            <td class="px-2 py-1 text-right font-mono border-r border-slate-100 font-bold text-slate-900 cp08-cell-p2"
                                data-galpon="${g}" data-metric="CU" data-val="${this.formatNum(gData.cu, 3)}">${this.formatNum(gData.cu, 3)}</td>
                            <td class="px-2 py-1 text-right font-mono border-r border-slate-100 ${difCuClass} cp08-cell-p2"
                                data-galpon="${g}" data-metric="Dif en CU" data-val="${gData.dif_cu !== 0 ? this.formatNum(gData.dif_cu, 3) : '-'}">${gData.dif_cu !== 0 ? this.formatNum(gData.dif_cu, 3) : '-'}</td>
                        `;
                    } else {
                        rowsHtml += `
                            <td class="px-2 py-1 text-right font-mono border-r border-slate-100 text-slate-300">-</td>
                            <td class="px-2 py-1 text-right font-mono border-r border-slate-100 text-slate-300">-</td>
                            <td class="px-2 py-1 text-right font-mono border-r border-slate-100 text-slate-300">-</td>
                            <td class="px-2 py-1 text-right font-mono border-r border-slate-100 text-slate-300">-</td>
                        `;
                    }
                });
            });

            rowsHtml += `</tr>`;
        });

        let tfootHtml = `
            <tr class="border-t-2 border-slate-300 font-bold text-slate-900">
                <td class="px-2 py-1.5 text-center border-r border-slate-200" colspan="2">Total General</td>
        `;

        grupos.forEach(grupo => {
            grupo.galpones.forEach(g => {
                const totG = (grupo.tabla2.totales_galpon && grupo.tabla2.totales_galpon[g]) || {};
                tfootHtml += `
                    <td class="px-2 py-1.5 text-right font-mono border-r border-slate-200 text-blue-900">${this.formatNum(totG.valor, 2)}</td>
                    <td class="px-2 py-1.5 text-right font-mono border-r border-slate-200 text-slate-700">${this.formatNum(totG.kilos, 2)}</td>
                    <td class="px-2 py-1.5 text-right font-mono border-r border-slate-200 text-blue-900">${this.formatNum(totG.cu, 3)}</td>
                    <td class="px-2 py-1.5 text-right border-r border-slate-200"></td>
                `;
            });
        });

        tfootHtml += `</tr>`;

        container.innerHTML = `
            <table id="cp08-tabla-p2" class="w-full text-xs border-collapse select-none">
                <thead class="sticky top-0 z-20 bg-blue-600 text-white border-b border-slate-300 font-bold text-center shadow-xs">
                    ${headerRow0}
                    ${headerRow1}
                    ${headerRow2}
                </thead>
                <tbody class="divide-y divide-slate-100 text-slate-800">
                    ${rowsHtml}
                </tbody>
                <tfoot class="sticky bottom-0 z-20 bg-slate-100 border-t-2 border-slate-300 shadow-md">
                    ${tfootHtml}
                </tfoot>
            </table>
        `;

        this.bindPanel2Events();
        this._restaurarScroll(container, scrollP2);
    },

    bindPanel2Events() {
        const self = this;
        const rows = document.querySelectorAll('.cp08-row-p2');

        rows.forEach(tr => {
            tr.addEventListener('click', function(e) {
                const lin = String(this.getAttribute('data-linea'));
                const nomlin = this.getAttribute('data-nomlinea') || '';
                const clave = self.claveLinea(lin, nomlin);
                const conCtrl = e.ctrlKey || e.metaKey;

                if (conCtrl) {
                    const indice = self.lineasSeleccionadas.indexOf(clave);

                    if (indice >= 0) {
                        self.lineasSeleccionadas.splice(indice, 1);
                    } else {
                        self.lineasSeleccionadas.push(clave);
                    }
                } else {
                    const soloEsta = self.lineasSeleccionadas.length === 1 && self.lineasSeleccionadas[0] === clave;
                    self.lineasSeleccionadas = soloEsta ? [] : [clave];
                }

                self.sincronizarSeleccionSimple();
                self.renderPanel2();
                self.renderPanel3();
            });

            tr.addEventListener('mouseenter', function(e) {
                const linea = this.getAttribute('data-linea');
                const nomlinea = this.getAttribute('data-nomlinea');

                self.showTooltip(e, {
                    'cencos': self.cencosActivo,
                    'fecha': self.datosBackend.fecha_formateada || self.datosBackend.fecha,
                    'nomcencos': self.nomcencosActivo,
                    'linea': `${linea} ${nomlinea}`
                });
            });

            tr.addEventListener('mousemove', function(e) {
                self.moveTooltip(e);
            });

            tr.addEventListener('mouseleave', function() {
                self.hideTooltip();
            });
        });
    },

    renderPanel3() {
        const container = document.getElementById('cp08-container-tabla-p3');
        const badgeLinea = document.getElementById('cp08-badge-linea-filtro');
        const badgeP3 = document.getElementById('cp08-badge-p3');
        if (!container) return;

        const scrollP3 = this._capturarScroll(container);

        const grupos = this.obtenerGruposPaneles()
            .map(grupo => ({ ...grupo, galpones: grupo.galpones3 || [] }))
            .filter(grupo => grupo.galpones.length > 0);

        if (badgeLinea) {
            const totalLineas = this.lineasSeleccionadas.length;
            badgeLinea.classList.toggle('hidden', totalLineas === 0);

            if (totalLineas > 0) {
                const lineasTexto = this.lineasSeleccionadas.map(clave => String(clave).split('||')[0]);

                badgeLinea.textContent = totalLineas === 1
                    ? `Línea: ${lineasTexto[0]} ✕`
                    : `Líneas: ${totalLineas} ✕`;
                badgeLinea.title = lineasTexto.join(', ');
            }
        }

        if (!grupos.length) {
            if (badgeP3) badgeP3.textContent = '0 Productos';
            container.innerHTML = `<div class="p-8 text-center text-slate-400 italic">No hay productos para las campañas y filtros seleccionados</div>`;
            return;
        }

        const itemsMap = new Map();
        const lineasSeleccionadasClaves = new Set(this.lineasSeleccionadas.map(clave => String(clave)));

        grupos.forEach(grupo => {
            const filasGrupo = (grupo.tabla3.filas || []).filter(r => {
                if (lineasSeleccionadasClaves.size && !lineasSeleccionadasClaves.has(this.claveLinea(r.linea, r.nomlinea))) {
                    return false;
                }

                return this.clasificacionCoincide(r);
            });

            filasGrupo.forEach(r => {
                const key = `${r.linea}||${r.nomlinea || ''}||${r.codigo}||${r.nomcodigo || ''}||${r.transaccion}`;

                if (!itemsMap.has(key)) {
                    itemsMap.set(key, {
                        linea: r.linea,
                        nomlinea: r.nomlinea || '',
                        codigo: r.codigo,
                        nomcodigo: r.nomcodigo || '',
                        transaccion: r.transaccion,
                        porGrupo: {}
                    });
                }

                itemsMap.get(key).porGrupo[grupo.cencos] = r;
            });
        });

        const items = Array.from(itemsMap.values());

        if (badgeP3) badgeP3.textContent = `${items.length} Productos`;

        if (!items.length) {
            container.innerHTML = `<div class="p-8 text-center text-slate-400 italic">No hay productos para las campañas y filtros seleccionados</div>`;
            return;
        }

        const gruposPorLinea = new Map();

        items.forEach(item => {
            const lin = String(item.linea);

            if (!gruposPorLinea.has(lin)) {
                gruposPorLinea.set(lin, []);
            }

            gruposPorLinea.get(lin).push(item);
        });

        const lineas = Array.from(gruposPorLinea.keys()).sort();

        let headerRow0 = `
            <tr>
                <th class="px-2 py-2 border-r border-slate-200" rowspan="3">linea</th>
                <th class="px-2.5 py-2 text-left border-r border-slate-200" rowspan="3">codigo</th>
                <th class="px-3 py-2 text-left border-r border-slate-200" rowspan="3">nomcodigo</th>
                <th class="px-1.5 py-2 text-center border-r border-slate-200" rowspan="3">trans..</th>
        `;
        let headerRow1 = `<tr>`;
        let headerRow2 = `<tr>`;

        grupos.forEach(grupo => {
            headerRow0 += `<th class="px-2 py-1 border-r border-slate-200 bg-blue-800 text-center font-bold tracking-wide" colspan="${grupo.galpones.length * 3}" title="${grupo.nomcencos || ''}">${grupo.cencos}</th>`;

            grupo.galpones.forEach(g => {
                headerRow1 += `<th class="px-2 py-1 border-r border-slate-200 bg-blue-700 text-center font-bold" colspan="3">${g}</th>`;
                headerRow2 += `
                    <th class="px-2 py-1 text-right border-r border-slate-200 text-[11px]">cantidad</th>
                    <th class="px-2 py-1 text-right border-r border-slate-200 text-[11px]">peso</th>
                    <th class="px-2 py-1 text-right border-r border-slate-200 text-[11px]">valor</th>
                `;
            });
        });

        headerRow0 += `</tr>`;
        headerRow1 += `</tr>`;
        headerRow2 += `</tr>`;

        let rowsHtml = '';

        lineas.forEach(lin => {
            const itemsLinea = gruposPorLinea.get(lin).sort((a, b) => {
                const codigo = String(a.codigo).localeCompare(String(b.codigo));
                if (codigo !== 0) return codigo;

                return String(a.transaccion).localeCompare(String(b.transaccion));
            });

            itemsLinea.forEach((r, idx) => {
                const lineaDisplay = idx === 0 ? `<span class="font-bold text-slate-800 font-mono">${r.linea}</span>` : '';

                rowsHtml += `
                    <tr class="hover:bg-slate-50 transition-colors border-t border-slate-100 cp08-row-p3"
                        data-linea="${r.linea}" data-codigo="${r.codigo}" data-nomcodigo="${r.nomcodigo}" data-transaccion="${r.transaccion}">
                        <td class="px-2 py-1 text-center font-mono border-r border-slate-100 select-none">${lineaDisplay}</td>
                        <td class="px-2.5 py-1 text-left font-mono font-semibold text-blue-900 border-r border-slate-100">${r.codigo}</td>
                        <td class="px-3 py-1 text-left font-mono text-slate-700 border-r border-slate-100 whitespace-nowrap text-[11px] truncate max-w-[200px]" title="${r.nomcodigo}">${r.nomcodigo}</td>
                        <td class="px-1.5 py-1 text-center font-mono font-bold text-slate-600 border-r border-slate-100">${r.transaccion}</td>
                `;

                grupos.forEach(grupo => {
                    const filaGrupo = r.porGrupo[grupo.cencos] || null;

                    grupo.galpones.forEach(g => {
                        const gData = (filaGrupo && filaGrupo.galpones && filaGrupo.galpones[g]) || null;

                        if (gData) {
                            rowsHtml += `
                                <td class="px-2 py-1 text-right font-mono border-r border-slate-100">${gData.cantidad !== 0 ? this.formatNum(gData.cantidad, 2) : '0'}</td>
                                <td class="px-2 py-1 text-right font-mono border-r border-slate-100">${gData.peso !== 0 ? this.formatNum(gData.peso, 2) : '0,00'}</td>
                                <td class="px-2 py-1 text-right font-mono border-r border-slate-100 font-medium">${this.formatNum(gData.valor, 2)}</td>
                            `;
                        } else {
                            rowsHtml += `
                                <td class="px-2 py-1 text-right font-mono border-r border-slate-100 text-slate-300"></td>
                                <td class="px-2 py-1 text-right font-mono border-r border-slate-100 text-slate-300"></td>
                                <td class="px-2 py-1 text-right font-mono border-r border-slate-100 text-slate-300"></td>
                            `;
                        }
                    });
                });

                rowsHtml += `</tr>`;
            });

            rowsHtml += `
                <tr class="bg-slate-50 font-bold border-t border-b border-slate-200 select-none text-[11px]">
                    <td class="border-r border-slate-200"></td>
                    <td class="px-2.5 py-1 text-left text-slate-600 font-semibold border-r border-slate-200" colspan="3">Total</td>
            `;

            grupos.forEach(grupo => {
                const subL = (grupo.tabla3.subtotales_linea && grupo.tabla3.subtotales_linea[lin]) || {};

                grupo.galpones.forEach(g => {
                    const sG = subL[g] || {};
                    rowsHtml += `
                        <td class="px-2 py-1 text-right font-mono text-slate-800 border-r border-slate-200">${sG.cantidad ? this.formatNum(sG.cantidad, 2) : ''}</td>
                        <td class="px-2 py-1 text-right font-mono text-slate-800 border-r border-slate-200">${sG.peso ? this.formatNum(sG.peso, 2) : ''}</td>
                        <td class="px-2 py-1 text-right font-mono text-slate-900 border-r border-slate-200 font-bold">${sG.valor ? this.formatNum(sG.valor, 2) : ''}</td>
                    `;
                });
            });

            rowsHtml += `</tr>`;
        });

        let tfootHtml = `
            <tr class="border-t-2 border-slate-300 font-bold text-slate-900">
                <td class="px-2 py-1.5 text-center border-r border-slate-200" colspan="4">Total general</td>
        `;

        grupos.forEach(grupo => {
            const totalesGenerales = grupo.tabla3.totales_generales || {};

            grupo.galpones.forEach(g => {
                const totG = totalesGenerales[g] || {};
                tfootHtml += `
                    <td class="px-2 py-1.5 text-right font-mono border-r border-slate-200 text-slate-800">${totG.cantidad ? this.formatNum(totG.cantidad, 2) : '0,00'}</td>
                    <td class="px-2 py-1.5 text-right font-mono border-r border-slate-200 text-slate-800">${totG.peso ? this.formatNum(totG.peso, 2) : '0,00'}</td>
                    <td class="px-2 py-1.5 text-right font-mono border-r border-slate-200 text-blue-900 font-bold">${totG.valor ? this.formatNum(totG.valor, 2) : '0,00'}</td>
                `;
            });
        });

        tfootHtml += `</tr>`;

        container.innerHTML = `
            <table id="cp08-tabla-p3" class="w-full text-xs border-collapse select-none">
                <thead class="sticky top-0 z-20 bg-blue-600 text-white border-b border-slate-300 font-bold text-center shadow-xs">
                    ${headerRow0}
                    ${headerRow1}
                    ${headerRow2}
                </thead>
                <tbody class="divide-y divide-slate-100 text-slate-800">
                    ${rowsHtml}
                </tbody>
                <tfoot class="sticky bottom-0 z-20 bg-slate-100 border-t-2 border-slate-300 shadow-md">
                    ${tfootHtml}
                </tfoot>
            </table>
        `;

        this.bindPanel3Events();
        this._restaurarScroll(container, scrollP3);
    },

    bindPanel3Events() {
        const self = this;
        const rows = document.querySelectorAll('.cp08-row-p3');

        rows.forEach(tr => {
            tr.addEventListener('mouseenter', function(e) {
                const linea = this.getAttribute('data-linea');
                const codigo = this.getAttribute('data-codigo');
                const nomcodigo = this.getAttribute('data-nomcodigo');
                const transaccion = this.getAttribute('data-transaccion');

                self.showTooltip(e, {
                    'cencos': self.cencosActivo,
                    'fecha': self.datosBackend.fecha_formateada || self.datosBackend.fecha,
                    'nomcencos': self.nomcencosActivo,
                    'linea': linea,
                    'codigo': `${codigo} ${nomcodigo}`,
                    'transaccion': transaccion
                });
            });

            tr.addEventListener('mousemove', function(e) {
                self.moveTooltip(e);
            });

            tr.addEventListener('mouseleave', function() {
                self.hideTooltip();
            });
        });
    },

    showTooltip(e, fields) {
        const tt = document.getElementById('tooltip-tableau-costos');
        if (!tt) return;

        let rowsHtml = '';
        Object.entries(fields).forEach(([k, v]) => {
            if (v !== undefined && v !== null && v !== '') {
                rowsHtml += `
                    <div class="flex items-center justify-between gap-4 py-0.5 border-b border-slate-100 last:border-0">
                        <span class="text-slate-500 font-medium">${k}:</span>
                        <span class="text-slate-900 font-semibold font-mono text-right">${v}</span>
                    </div>
                `;
            }
        });

        tt.innerHTML = `
            <div class="flex flex-col gap-1 text-[11px] font-sans">
                ${rowsHtml}
            </div>
        `;

        tt.classList.remove('hidden');
        this.moveTooltip(e);
    },

    moveTooltip(e) {
        const tt = document.getElementById('tooltip-tableau-costos');
        if (!tt || tt.classList.contains('hidden')) return;

        const pad = 15;
        let x = e.clientX + pad;
        let y = e.clientY + pad;

        const ttWidth = tt.offsetWidth || 260;
        const ttHeight = tt.offsetHeight || 140;
        const winWidth = window.innerWidth;
        const winHeight = window.innerHeight;

        if (x + ttWidth > winWidth - 10) {
            x = e.clientX - ttWidth - pad;
        }
        if (y + ttHeight > winHeight - 10) {
            y = e.clientY - ttHeight - pad;
        }

        tt.style.left = `${Math.max(10, x)}px`;
        tt.style.top = `${Math.max(10, y)}px`;
    },

    hideTooltip() {
        const tt = document.getElementById('tooltip-tableau-costos');
        if (tt) tt.classList.add('hidden');
    },

    formatNum(num, decimals = 2) {
        if (num === null || num === undefined || isNaN(num)) return '-';
        return Number(num).toLocaleString('es-PE', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        });
    }
};

// Registro modular
if (!window.ChartRegistry) window.ChartRegistry = {};
window.ChartRegistry['CP08 ComparativoGranjaGalpon'] = window.ChartCP08ComparativoGranjaGalpon;
window.ChartRegistry['CP08ComparativoGranjaGalpon'] = window.ChartCP08ComparativoGranjaGalpon;
window.ChartRegistry['CP08 Comparativo Granja Galpon'] = window.ChartCP08ComparativoGranjaGalpon;
window.ChartRegistry['CP08'] = window.ChartCP08ComparativoGranjaGalpon;
window.ChartRegistry['CP08 ComparativoGranjaGalpón'] = window.ChartCP08ComparativoGranjaGalpon;
