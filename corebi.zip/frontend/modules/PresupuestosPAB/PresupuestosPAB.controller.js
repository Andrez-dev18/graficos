const PRESUPUESTOS_DASH = [
    { codigo: '202403', nombre: '202403' },
    { codigo: '202403%', nombre: '202403%' },
    { codigo: '202404', nombre: '202404' },
    { codigo: '202404%', nombre: '202404%' },
    { codigo: '202410', nombre: '202410' },
    { codigo: '202410%', nombre: '202410%' },
    { codigo: '202503', nombre: '202503' },
    { codigo: '202503%', nombre: '202503%' }
];

const PRESUPUESTOS_ANALISIS = [
    { codigo: '202410', nombre: '202410' },
    { codigo: '202404', nombre: '202404' },
    { codigo: '202403', nombre: '202403' },
    { codigo: '202405', nombre: '202405' },
    { codigo: '202401', nombre: '202401' },
    { codigo: '202503', nombre: '202503' }
];

const BUDGET_PAIRS = {
    '202403': { pct: 'DashPresupuesto202403Pct', det: 'DashPresupuesto202403' },
    '202403%': { pct: 'DashPresupuesto202403Pct', det: 'DashPresupuesto202403' },
    '202404': { pct: 'DashPresupuesto202404Pct', det: 'DashPresupuesto202404' },
    '202404%': { pct: 'DashPresupuesto202404Pct', det: 'DashPresupuesto202404' },
    '202410': { pct: 'DashPresupuesto202410Pct', det: 'DashPresupuesto202410' },
    '202410%': { pct: 'DashPresupuesto202410Pct', det: 'DashPresupuesto202410' },
    '202503': { pct: 'DashPresupuesto202503Pct', det: 'DashPresupuesto202503' },
    '202503%': { pct: 'DashPresupuesto202503Pct', det: 'DashPresupuesto202503' }
};

const CHART_MAP = {
    '202403': 'DashPresupuesto202403',
    '202403%': 'DashPresupuesto202403Pct',
    '202404': 'DashPresupuesto202404',
    '202404%': 'DashPresupuesto202404Pct',
    '202410': 'DashPresupuesto202410',
    '202410%': 'DashPresupuesto202410Pct',
    '202503': 'DashPresupuesto202503',
    '202503%': 'DashPresupuesto202503Pct'
};

/**
 * Controlador para el Módulo Presupuestos PAB
 * Administra filtros de período (PeriodoHelper), tipo de gráfico y despacho al ChartRegistry.
 */
class PresupuestosPABController {
    constructor() {
        this.service = new PresupuestosPABService();
        this.chartTipoActual = 'DashPresupuesto';
        this.datosDashboard = null;
        this.misPresupuestosAutorizados = [];
        this.tieneRestriccionPresupuesto = false;
        this.init();
    }

    async init() {
        this.setupPeriodo();
        this.setupListeners();
        await this.cargarPermisosUsuario();
        this.actualizarVisibilidadControles();
        await this.onCargarClick();
    }

    async cargarPermisosUsuario() {
        try {
            const resp = await this.service.obtenerMisPresupuestos();
            if (resp && resp.success && resp.data && Array.isArray(resp.data.presupuestos)) {
                this.misPresupuestosAutorizados = resp.data.presupuestos;
            } else {
                this.misPresupuestosAutorizados = [];
            }
        } catch (e) {
            console.warn('No se pudieron obtener los permisos de presupuesto del usuario:', e);
            this.misPresupuestosAutorizados = [];
        }
    }

    obtenerPresupuestosDashPermitidos() {
        // Si el usuario no tiene presupuestos asignados, la lista es vacía
        if (!this.misPresupuestosAutorizados || this.misPresupuestosAutorizados.length === 0) {
            return [];
        }
        return PRESUPUESTOS_DASH.filter(p => {
            const codBase = p.codigo.replace('%', '');
            return this.misPresupuestosAutorizados.includes(codBase);
        });
    }

    setupPeriodo() {
        if (typeof PeriodoHelper !== 'undefined') {
            const selPeriodo = document.getElementById('select-tipo-periodo');
            if (selPeriodo) {
                selPeriodo.value = 'entre_fechas';
            }
            PeriodoHelper.renderizarInputs();
        }
    }

    setupListeners() {
        // Selector de tipo de período dinámico
        const selPeriodo = document.getElementById('select-tipo-periodo');
        if (selPeriodo) {
            selPeriodo.addEventListener('change', () => {
                if (typeof PeriodoHelper !== 'undefined') {
                    PeriodoHelper.renderizarInputs();
                }
            });
        }

        // Selector de tipo de gráfico
        const selTipoGrafico = document.getElementById('select-tipo-grafico');
        if (selTipoGrafico) {
            selTipoGrafico.addEventListener('change', async () => {
                this.actualizarVisibilidadControles();
                await this.onCargarClick();
            });
        }

        // Checkbox para combinar resumen % y detalle
        const chkMostrarAmbos = document.getElementById('check-mostrar-ambos');
        if (chkMostrarAmbos) {
            chkMostrarAmbos.addEventListener('change', async () => {
                await this.onCargarClick();
            });
        }

        // Selector dinámico de presupuesto en la barra superior de filtros
        const selFiltroPresu = document.getElementById('select-filtro-presupuesto');
        if (selFiltroPresu) {
            selFiltroPresu.addEventListener('change', async () => {
                await this.onCargarClick();
            });
        }

        // Toggle plegar / desplegar barra de filtros
        const btnToggle = document.getElementById('btn-toggle-filtros');
        const contFiltros = document.getElementById('contenedor-filtros-contenido');
        const iconToggle = document.getElementById('icon-toggle-filtros');
        const labelToggle = document.getElementById('label-toggle-filtros');

        if (btnToggle && contFiltros) {
            btnToggle.addEventListener('click', () => {
                const estaOculto = contFiltros.classList.toggle('hidden');
                if (labelToggle) labelToggle.textContent = estaOculto ? 'Mostrar filtros' : 'Ocultar filtros';
                if (iconToggle) iconToggle.style.transform = estaOculto ? 'rotate(180deg)' : 'rotate(0deg)';
            });
        }

        // Botón Cargar
        document.getElementById('btn-cargar')?.addEventListener('click', async () => {
            await this.onCargarClick();
        });

        // Botón Limpiar
        document.getElementById('btn-limpiar')?.addEventListener('click', async () => {
            this.setupPeriodo();
            await this.onCargarClick();
        });
    }

    actualizarVisibilidadControles() {
        const selTipoGrafico = document.getElementById('select-tipo-grafico');
        const contPresu = document.getElementById('contenedor-filtro-presupuesto');
        const selFiltroPresu = document.getElementById('select-filtro-presupuesto');
        const contCombinar = document.getElementById('contenedor-check-combinar');

        const tipo = selTipoGrafico ? selTipoGrafico.value : 'DashPresupuesto';
        const esDashPresupuesto = (tipo === 'DashPresupuesto');

        if (contCombinar) {
            if (esDashPresupuesto) {
                contCombinar.classList.remove('hidden');
            } else {
                contCombinar.classList.add('hidden');
            }
        }

        if (contPresu) {
            contPresu.classList.remove('hidden');
        }

        if (selFiltroPresu) {
            const actualVal = selFiltroPresu.value;
            if (esDashPresupuesto) {
                const listaPermitida = this.obtenerPresupuestosDashPermitidos();
                if (listaPermitida.length > 0) {
                    selFiltroPresu.disabled = false;
                    const existe = listaPermitida.some(p => p.codigo === actualVal);
                    const seleccionado = existe ? actualVal : listaPermitida[0].codigo;
                    selFiltroPresu.innerHTML = listaPermitida.map(p => {
                        const isSel = (p.codigo === seleccionado) ? 'selected' : '';
                        return `<option value="${p.codigo}" ${isSel}>${p.nombre}</option>`;
                    }).join('');
                    if (contCombinar) contCombinar.classList.remove('hidden');
                } else {
                    selFiltroPresu.disabled = true;
                    selFiltroPresu.innerHTML = `<option value="">-- Sin presupuestos asignados --</option>`;
                    if (contCombinar) contCombinar.classList.add('hidden');
                }
            } else {
                selFiltroPresu.disabled = false;
                const lista = (this.datosDashboard && this.datosDashboard.presupuestos_disponibles) ? this.datosDashboard.presupuestos_disponibles : PRESUPUESTOS_ANALISIS;
                const existe = lista.some(p => p.codigo === actualVal);
                const seleccionado = existe ? actualVal : '202410';
                selFiltroPresu.innerHTML = lista.map(p => {
                    const isSel = (p.codigo === seleccionado) ? 'selected' : '';
                    return `<option value="${p.codigo}" ${isSel}>${p.nombre || p.codigo}</option>`;
                }).join('');
            }
        }
    }

    actualizarVisibilidadFiltroPresupuesto() {
        this.actualizarVisibilidadControles();
    }

    actualizarOpcionesPresupuesto(lista = [], seleccionado = '202410') {
        const selTipoGrafico = document.getElementById('select-tipo-grafico');
        const tipo = selTipoGrafico ? selTipoGrafico.value : '';
        if (tipo === 'DashPresupuesto') return;

        const selFiltroPresu = document.getElementById('select-filtro-presupuesto');
        if (!selFiltroPresu || !lista.length) return;

        const actualVal = selFiltroPresu.value || seleccionado;
        selFiltroPresu.innerHTML = lista.map(p => {
            const isSel = (p.codigo === actualVal) ? 'selected' : '';
            return `<option value="${p.codigo}" ${isSel}>${p.nombre || p.codigo}</option>`;
        }).join('');
    }

    async onCargarClick() {
        const btnCargar = document.getElementById('btn-cargar');
        const originalBtnHtml = btnCargar ? btnCargar.innerHTML : '';

        if (btnCargar) {
            btnCargar.disabled = true;
            btnCargar.classList.add('opacity-75', 'cursor-not-allowed');
            btnCargar.innerHTML = `
                <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Cargando...</span>
            `;
        }

        try {
            const selTipoGrafico = document.getElementById('select-tipo-grafico');
            const tipoGrafico = selTipoGrafico ? selTipoGrafico.value : 'DashPresupuesto';
            this.chartTipoActual = tipoGrafico;

            const selPresu = document.getElementById('select-filtro-presupuesto');
            const codigoPresu = (selPresu && selPresu.value) ? selPresu.value : '202403';

            const chkMostrarAmbos = document.getElementById('check-mostrar-ambos');
            const mostrarAmbos = chkMostrarAmbos ? chkMostrarAmbos.checked : false;

            // Extraer fechas del PeriodoHelper si existen
            let rango = {};
            if (typeof PeriodoHelper !== 'undefined' && PeriodoHelper.obtenerRangoFechas) {
                rango = PeriodoHelper.obtenerRangoFechas();
            }

            const contGraficos = document.getElementById('contenedor-graficos-lista');
            if (contGraficos) contGraficos.innerHTML = '';

            if (tipoGrafico === 'DashPresupuesto') {
                const listaPermitida = this.obtenerPresupuestosDashPermitidos();
                if (listaPermitida.length === 0) {
                    if (contGraficos) {
                        contGraficos.innerHTML = `
                            <div class="bg-amber-50 border border-amber-200 text-amber-800 p-8 rounded-2xl text-center mx-auto max-w-lg my-8">
                                <i class="fas fa-lock text-3xl text-amber-500 mb-3"></i>
                                <h3 class="text-base font-bold">Sin acceso a presupuestos</h3>
                                <p class="text-xs text-amber-600 mt-1">No tienes presupuestos asignados para visualizar en este módulo. Contacta a un administrador.</p>
                            </div>
                        `;
                    }
                    return;
                }

                const existeVal = listaPermitida.some(p => p.codigo === codigoPresu);
                const codFinal = existeVal ? codigoPresu : listaPermitida[0].codigo;
                const pair = BUDGET_PAIRS[codFinal] || BUDGET_PAIRS['202403'];

                if (mostrarAmbos) {
                    // Modo combinado: Cargar Resumen % (primero) y Detalle (segundo)
                    const [respPct, respDet] = await Promise.all([
                        this.service.obtenerDashboard({
                            tipo_grafico: pair.pct,
                            fecha_inicio: rango.fechaInicio || '',
                            fecha_fin: rango.fechaFin || ''
                        }),
                        this.service.obtenerDashboard({
                            tipo_grafico: pair.det,
                            fecha_inicio: rango.fechaInicio || '',
                            fecha_fin: rango.fechaFin || ''
                        })
                    ]);

                    if (!respPct || respPct.status !== 'success' || !respDet || respDet.status !== 'success') {
                        console.error('Error al obtener datos combinados:', { respPct, respDet });
                        alert('No se pudieron cargar los datos combinados del presupuesto.');
                        return;
                    }

                    const dataPct = respPct.data || respPct.payload || {};
                    const dataDet = respDet.data || respDet.payload || {};

                    if (contGraficos) {
                        contGraficos.innerHTML = `
                            <div id="contenedor-resumen-pct" class="w-full"></div>
                            <div id="contenedor-detalle-presupuesto" class="w-full"></div>
                        `;
                    }

                    // Renderizar primero el resumen (%)
                    if (window.ChartRegistry && window.ChartRegistry[pair.pct]) {
                        window.ChartRegistry[pair.pct].render(this, dataPct, 'contenedor-resumen-pct');
                    }

                    // Renderizar segundo el detalle
                    if (window.ChartRegistry && window.ChartRegistry[pair.det]) {
                        window.ChartRegistry[pair.det].render(this, dataDet, 'contenedor-detalle-presupuesto');
                    }
                } else {
                    // Modo individual: determinar componente según código (con o sin %)
                    const targetChart = CHART_MAP[codFinal] || 'DashPresupuesto202403';
                    const resp = await this.service.obtenerDashboard({
                        tipo_grafico: targetChart,
                        fecha_inicio: rango.fechaInicio || '',
                        fecha_fin: rango.fechaFin || ''
                    });

                    if (!resp || resp.status !== 'success') {
                        console.error('Error al obtener datos:', resp);
                        alert('No se pudieron cargar los datos del presupuesto.');
                        return;
                    }

                    this.datosDashboard = resp.data || resp.payload;

                    if (window.ChartRegistry && window.ChartRegistry[targetChart]) {
                        window.ChartRegistry[targetChart].render(this, this.datosDashboard, contGraficos);
                    } else if (window.ChartRegistry && window.ChartRegistry['DashPresupuesto202403']) {
                        window.ChartRegistry['DashPresupuesto202403'].render(this, this.datosDashboard, contGraficos);
                    }
                }
            } else {
                // Modo AnalisisPartidas o DashComparativoCronoRC
                const filtros = {
                    tipo_grafico: tipoGrafico,
                    presupuesto: codigoPresu,
                    fecha_inicio: rango.fechaInicio || '',
                    fecha_fin: rango.fechaFin || ''
                };

                const resp = await this.service.obtenerDashboard(filtros);

                if (!resp || resp.status !== 'success') {
                    console.error('Error al obtener datos:', resp);
                    alert('No se pudieron cargar los datos del reporte.');
                    return;
                }

                this.datosDashboard = resp.data || resp.payload;

                // Si devuelve lista de presupuestos disponibles, sincronizar el select
                if (this.datosDashboard && this.datosDashboard.presupuestos_disponibles) {
                    this.actualizarOpcionesPresupuesto(
                        this.datosDashboard.presupuestos_disponibles,
                        this.datosDashboard.presupuesto_seleccionado || codigoPresu
                    );
                }

                if (window.ChartRegistry && window.ChartRegistry[tipoGrafico]) {
                    window.ChartRegistry[tipoGrafico].render(this, this.datosDashboard, contGraficos);
                } else {
                    console.warn(`No se encontró componente registrado para tipo_grafico="${tipoGrafico}".`);
                }
            }
        } catch (error) {
            console.error('Error en onCargarClick:', error);
        } finally {
            if (btnCargar) {
                btnCargar.disabled = false;
                btnCargar.classList.remove('opacity-75', 'cursor-not-allowed');
                btnCargar.innerHTML = originalBtnHtml;
            }
        }
    }
}

// Inicialización automática al cargar el DOM
document.addEventListener('DOMContentLoaded', () => {
    window.presupuestosPABController = new PresupuestosPABController();
});
