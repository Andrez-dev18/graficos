/**
 * Servicio para Costos Tradicionales - Costo de Producción Pollo Vivo (CP01 y CP02)
 * Consume la API del Backend (/costosTradicionales/dashboard)
 */
class CostosTradicionalesService {
    constructor() {
        this.baseUrl = AppConfig.API.BASE_URL;
    }

    /**
     * Consulta los datos reales del dashboard de Costos Tradicionales
     * @param {Object} filtros { fecha_inicio: 'YYYY-MM-DD', fecha_fin: 'YYYY-MM-DD', tipo_grafico: 'CPO1CostoProduccion' | 'CP02 CPVvsCA' }
     */
    async obtenerDashboard(filtros = {}) {
        try {
            const url = `${this.baseUrl}/costosTradicionales/dashboard`;
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(filtros)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Error en CostosTradicionalesService.obtenerDashboard:', error);
            return {
                success: false,
                status: 'error',
                message: error.message || 'Error de conexión con el servidor backend',
                payload: {
                    benchmark: 4.538,
                    periodos: [],
                    graficaCosto: [],
                    graficaCP02: [],
                    tablaMetricas: []
                }
            };
        }
    }
}
